## VERSION 1.6.2
- Implemented a new Joomla Table for news_changelogs