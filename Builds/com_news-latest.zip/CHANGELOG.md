## VERSION 1.6.7.2
- Implemented a new Joomla Table for news_changelogs